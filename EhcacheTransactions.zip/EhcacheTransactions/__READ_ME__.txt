Contents:

1) WxEhcache.zip IS package.
2) WmEhcacheTransactionManager.jar

FOR COMPLETE AND DETAILED CONFIGURATION AND USAGE DOCUMENT.... PLEASE INSTALL THE PACKAGE AND VISIT PACKAGE HOME PAGE FROM IS ADMIN PACKAGE MANAGEMENT CONSOLE.

Navigate to: IS ADMIN --> Packages --> Management 

CLICK on HOME ICON beside WxEhcache PACKAGE for FULL DOCUMENTATION


Package Developed by: PRASAD POKALA
Please contact me at pvkksgp@gmail.com in case you need any details.